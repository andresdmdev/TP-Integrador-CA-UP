history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
clear
ls
ls
cd ..
ls
cat etc/hosts
clear
hostnamectl
nano etc/host
nano etc/hosts
vi etc/hosts
clear
vi etc/hosts
cat etc/host
cat etc/hosts
vi etc/hosts
clear
cat etc/hosts
sudo apt-get install nano
sudo apt update
sudo apt install nano -y
nano --version
ping google.com
clear
sudo apt install nano -y
apt update
sudo apt install nano -
loadkeys us
loadkeys es
clear
ls
vi etc/apt/sources.list
clear
apt update
vi etc/apt/sources.list
clear
apt update
apt list --upgradable
clear
apt install nano -y
nano etc/hosts
cat etc/hosts
clear
sudo hostnamectl set-hostname TPServer
hostnamectl
exec bash
clear
apt update
apt
apt full-upgrade -y
apt autoremove -y
ls
cd ..
ls
cat etc/apt/sources.list
sed -i 's/bullseye/bookworm/g' /etc/apt/sources.list
cat etc/apt/sources.list
apt update
clear
apt upgrade --without-new-pkgs -y
apt full-upgrade -y
apt autoremove -y
reboot
systemctl status ssh
ls
cd ..
clear
ls
cd home/
clear
ls
ssh-keygen -t rsa -b 4096 -f .ssh/id_rsa -N ""
ssh-keygen -t rsa -b 4096 -f /.ssh/id_rsa -N ""
ls
ssh-keygen -t rsa -b 4096 -f .ssh/id_rsa -N ""
mkdir .ssh
ls
ls -a
ssh-keygen -t rsa -b 4096 -f .ssh/id_rsa -N ""
clear
ls
cd .ssh/
ls
,.,,ññ'pñññ
clear
nano --version
loadkey is
loadkey es
loadkeys es
clear
ls
cd ..
ls
cd home/
ls
ls -a
clear
cat .ssh/id_rsa.pub 
dpkg-reconfigure keyboard-configuration
clear
dpkg-reconfigure keyboard-configuration
clear
dpkg-reconfigure keyboard-configuration
clear
dpkg-reconfigure keyboard-configuration
clear
setupcon
reboot
ls
ls
clear
ls
ls
cdcd Material_Adicional_TPVMCA
cd Material_Adicional_TPVMCA/
ls
