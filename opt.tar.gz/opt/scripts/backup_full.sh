#!/bin/bash

DIR_1=$1
DIR_2=$2
DATE_FORMAT=$(date +%Y%m%d)

if [[ "$1" == "-h" || "$1" == "--help"  ]]; then
	echo ""
	echo "Uso: $0 <origen> <destino>"
	echo ""
	echo "Argumentos:"
	echo "	origen		Ruta de la carpeta a respaldar."
	echo "	destino 	Ruta de la carpeta donde se guardara el  .tar.gz"
	echo ""
	echo "Opciones:"
	echo "	-h, --help	Muestra este mensaje de ayuda."
	echo ""
	echo "Ejemplo:"
	echo "	$0 /home/usuario/documentos /var/backups"
	echo ""
	echo "	bash $0 /home/usuario/documentos /var/backups"
	echo ""
	echo "Autor: Andres Marquez"
	exit 0
fi


if [[ ! -d $DIR_1 ]]; then

	read -p "Ingresar la ruta de la carpeta a comprimir: " DIR_1

	while [[ ! -d $DIR_1 ]]; do
		read -p "Ingresar la ruta de la carpeta a comprimir: " DIR_1
	done
fi

if [[ ! -d $DIR_2 ]]; then

	read -p "Desea que la ruta de destino sea la default? (y/n): " IS_DEFAULT

	while [[ $IS_DEFAULT != "y" && $IS_DEFAULT != "n" ]]; do
		read -p "Error | Desea que la ruta de destino sea la default? (y/n): " IS_DEFAULT
	done

	if [[ $IS_DEFAULT == "n"  ]]; then

		read -p "Ingresar la ruta de destino del archivo comprimido: " DIR_2

		while [[ ! -d $DIR_2 ]]; do
			read -p "Ingresar la ruta de destino del archivo comprimido: " DIR_2
		done
	else

		DIR_2="/backup_dir"
	fi
fi

FOLDER_NAME=$(basename "$DIR_1")
NEW_NAME="${FOLDER_NAME}_bkp_${DATE_FORMAT}.tar.gz"

tar -czvf "$NEW_NAME" "$DIR_1" && mv "$NEW_NAME" "$DIR_2"

echo "Respaldado correctamente con el nombre: ${NEW_NAME}!"
